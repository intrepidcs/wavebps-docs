#ifndef _MATLABBLOCK_H
#define _MATLABBLOCK_H

#include <fstream>
#include <string>

using namespace std;

enum DataFormatEnum
{
	Double = 0,
	Single = 10,
	Integer = 20,
};

struct stMatlabHeader
{
	int DataFormat;
	int NumberOfValues;
	int Reserved1;
	int Reserved0;
	int NameLength;
};

class CMatlabBlock
{
public:
	CMatlabBlock( ifstream& file );
	CMatlabBlock( const CMatlabBlock& rhs );
	CMatlabBlock& operator =( const CMatlabBlock& rhs );
	~CMatlabBlock();
	
	size_t GetDataSize() const { return m_DataSize; }
	const unsigned char* GetData() const { return m_pData; }
	const string& GetName() const { return m_sName; }
	const stMatlabHeader& GetHeader() const { return m_Header; }

	class ReadFileError
	{
	};

	class GotEOF
	{
	};
		
private:
	size_t m_DataSize;
	unsigned char* m_pData;
	string m_sName;
	stMatlabHeader m_Header;

};

#endif