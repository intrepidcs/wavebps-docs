#include "CMatlabBlock.h"

CMatlabBlock::CMatlabBlock( ifstream& file ) : m_DataSize(0), m_pData(NULL)
{
	file.read( (char*)&m_Header, sizeof(stMatlabHeader) );
	if( file.eof() )
		throw GotEOF();
	else if( file.fail() )
		throw ReadFileError();

	char* sFilename = new char[ m_Header.NameLength ];
	file.read( sFilename, m_Header.NameLength );
	if( file.fail() )
	{
		delete [] sFilename;
		throw ReadFileError();
	}
	m_sName = sFilename;
	delete [] sFilename;

	size_t valuesize;
	switch( m_Header.DataFormat )
	{
	case Double:
		valuesize = sizeof(double);
		break;
	case Single:
		valuesize = sizeof(float);
		break;
	case Integer:
		valuesize = sizeof(int);
		break;
	default:
		throw ReadFileError();
	}

	m_DataSize = valuesize * m_Header.NumberOfValues;
	m_pData = new unsigned char[ m_DataSize ];
	file.read( (char*)m_pData, m_DataSize );
}

CMatlabBlock::CMatlabBlock( const CMatlabBlock& rhs )
{
	*this = rhs;
}

CMatlabBlock::~CMatlabBlock()
{
	if( m_pData )
		delete [] m_pData;
}

CMatlabBlock& CMatlabBlock::operator =( const CMatlabBlock& rhs )
{
	m_Header = rhs.m_Header;
	m_sName = rhs.m_sName;
	m_DataSize = rhs.m_DataSize;
	if( m_DataSize > 0 )
	{
		m_pData = new unsigned char[ m_DataSize ];
		memcpy( m_pData, rhs.m_pData, m_DataSize );
	}
	else
		m_pData = NULL;

	return *this;
}