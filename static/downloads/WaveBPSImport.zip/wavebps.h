#ifndef _WAVEBPS_H
#define _WAVEBPS_H

#define WAVEBPSEXPORT int _stdcall

typedef void*(_stdcall *SETBUFFSIZEPROC)(int iChannel, int iBufferSize, int iMaintainValues);
typedef int(_stdcall *UPDATEPROGRESSBARPROC)(int iShow, int iPercent);
typedef int(_stdcall *SETCHANNEL_BUFFERINFO)(int iNumChannels, int  iDataType, double  dVoltsPerCount, double dSampleRateInMicroseconds);

struct stWaveformPoint
{
	double dMicroseconds;
	float dVoltage;
};

extern "C"
{
	WAVEBPSEXPORT WaveBPSImportGetInfo(wchar_t* sDescription, wchar_t* sDialogFileSpec, int* piAPIVersion, int* piDLLVersion);
	WAVEBPSEXPORT WaveBPSImportData(const wchar_t* sFilePath, SETBUFFSIZEPROC SetBufferSize, UPDATEPROGRESSBARPROC UpdateProgressBar, SETCHANNEL_BUFFERINFO 	SetChannelBufferInfo);
}

#endif